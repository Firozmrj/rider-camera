const SHEET_NAME = 'Info';
const DEFAULT_PIN = '1234'; // Behtar: Project Settings > Script Properties me PIN naam se apna PIN daalo
const MAX_FAILS = 8;        // itne galat PIN ke baad 10 minute lock
const GEMINI_MODEL = 'gemini-3.8-flash';             // current fast/stable Gemini Flash
const GEMINI_BACKUP_MODEL = 'gemini-3.5-flash-lite'; // pehla fail ho to ye chalega
const SHEET_CACHE_SEC = 60; // sheet data itni der (sec) cache rahega. Naya rider na dikhe to kam karo


function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Rider Scanner (Gemini)')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}


function digits(s) {
  return String(s || '')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/\D/g, '');
}


/* ---------- PIN (brute-force protection ke saath) ---------- */
function checkPin_(pin) {
  const cache = CacheService.getScriptCache();
  const fails = Number(cache.get('pinfails') || 0);
  if (fails >= MAX_FAILS) return 'Bahut galat PIN. 10 minute baad try karo.';
  const real = PropertiesService.getScriptProperties().getProperty('PIN') || DEFAULT_PIN;
  if (String(pin || '') !== String(real)) {
    cache.put('pinfails', String(fails + 1), 600);
    return 'Galat PIN';
  }
  if (fails) cache.remove('pinfails');
  return null;
}


/* ---------- Sheet reader (cache ke saath) ---------- */
function readSheet_(fresh) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) return { error: 'Script Google Sheet se juda nahi hai. Sheet me Extensions > Apps Script se kholo.' };


  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.getSheets().find(s => s.getName().trim().toLowerCase() === SHEET_NAME.toLowerCase());
  if (!sh) return { error: 'Info naam ki sheet nahi mili. Sheet tab ka naam Info rakho.' };


  const cache = CacheService.getScriptCache();
  const ckey = 'sheetdata_' + sh.getSheetId();
  let data = null, fromCache = false;


  if (!fresh) {
    try {
      const c = cache.get(ckey);
      if (c) { data = JSON.parse(c); fromCache = true; }
    } catch (e) { data = null; }
  }
  if (!data) {
    data = sh.getDataRange().getDisplayValues();
    try { cache.put(ckey, JSON.stringify(data), SHEET_CACHE_SEC); } catch (e) {} // 100KB se badi ho to cache skip
  }


  if (data.length < 2) return { error: 'Sheet "' + sh.getName() + '" me data nahi hai (row 1 header, row 2 se riders).' };


  const head = data[0].map(h => String(h).trim());
  const norm = h => String(h).toLowerCase().replace(/[^a-z]/g, '');


  const vCol = head.findIndex(h => /^(vehicle|vechile|vehical|vehicel|plate)/.test(norm(h)));
  if (vCol < 0) return { error: 'Vehicle number ka column nahi mila (header: Vehicle No). Mile hue headers: ' + head.join(', ') };


  const pCol = head.findIndex(h => /^photo/.test(norm(h)));
  return { sh: sh, data: data, head: head, vCol: vCol, pCol: pCol, fromCache: fromCache };
}


/* ---------- Gemini: photo se Kuwait plate padhna ---------- */
const PLATE_PROMPT =
  'Read Kuwait vehicle license plates in this photo (delivery motorbikes or cars, phone photo, maybe angled, dark or dirty). ' +
  'A Kuwait plate may contain a short prefix/series (usually 1-2 digits) and a longer serial (usually 3-6 digits). ' +
  'Read only digits physically printed on the vehicle registration plate. Ignore Arabic text, KUWAIT, stickers, phone numbers, logos, dates and background text. ' +
  'Convert Arabic-Indic and Eastern Arabic digits to Western digits. Put the short prefix in prefix and the long number in serial; do not merge them. ' +
  'Return up to 3 plausible plate readings, most likely first, with confidence from 0 to 1. Never invent unreadable digits; if no plate is visible return an empty plates array.';


function buildBody_(b64, mime, model, withThinking) {
  const gc = {
    temperature: 0,
    maxOutputTokens: 300,
    responseMimeType: 'application/json',
    responseSchema: {
      type: 'OBJECT',
      properties: {
        plates: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              prefix: { type: 'STRING' },
              serial: { type: 'STRING' },
              confidence: { type: 'NUMBER' }
            },
            required: ['serial']
          }
        }
      },
      required: ['plates']
    }
  };
  if (withThinking) {
    // Thinking band/kam = bahut tez. Gemini 3.x: thinkingLevel, Gemini 2.5: thinkingBudget
    if (/^gemini-3/.test(model)) gc.thinkingConfig = { thinkingLevel: 'minimal' };
    else gc.thinkingConfig = { thinkingBudget: 0 };
  }
  return {
    contents: [{ parts: [
      { text: PLATE_PROMPT },
      { inline_data: { mime_type: mime || 'image/jpeg', data: b64 } }
    ] }],
    generationConfig: gc
  };
}


function callGemini_(key, model, body) {
  return UrlFetchApp.fetch(
    'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', {
    method: 'post',
    contentType: 'application/json',
    headers: { 'x-goog-api-key': key },
    payload: JSON.stringify(body),
    muteHttpExceptions: true
  });
}


function askGemini_(b64, mime) {
  const key = PropertiesService.getScriptProperties().getProperty('GEMINI_KEY');
  if (!key) return { error: 'GEMINI_KEY set nahi hai. Project Settings > Script Properties me GEMINI_KEY naam se key daalo.' };


  const MODELS = [GEMINI_MODEL, GEMINI_BACKUP_MODEL]; // pehla fail ho to doosra try hoga
  let code = 0, txt = '';


  for (let m = 0; m < MODELS.length; m++) {
    const model = MODELS[m];
    let resp;
    try {
      resp = callGemini_(key, model, buildBody_(b64, mime, model, true));
      code = resp.getResponseCode();
      txt = resp.getContentText();


      // thinkingConfig is model ko pasand nahi aaya -> bina uske dobara
      if (code === 400 && /thinking/i.test(txt)) {
        resp = callGemini_(key, model, buildBody_(b64, mime, model, false));
        code = resp.getResponseCode();
        txt = resp.getContentText();
      }
    } catch (e) {
      txt = String(e && e.message || e);
      code = -1;
      // Ek model/network call fail ho to backup model ko bhi mauka do.
      continue;
    }
    if (code === 200) break;
    // Rate limit / overload par wait nahi karte; agla model turant try hota hai.
  }


  if (code !== 200) {
    let msg = txt.slice(0, 200);
    try { msg = JSON.parse(txt).error.message; } catch (e) {}
    return { error: 'Gemini error (' + code + '): ' + msg };
  }
  try {
    const j = JSON.parse(txt);
    const parts = j && j.candidates && j.candidates[0] &&
      j.candidates[0].content && j.candidates[0].content.parts || [];
    const part = parts.find(x => x && typeof x.text === 'string');
    if (!part) return { error: 'Gemini ne readable plate result nahi diya. Dobara scan karo.' };
    const out = JSON.parse(part.text);
    const plates = (Array.isArray(out.plates) ? out.plates : [])
      .map(p => ({
        prefix: digits(p && p.prefix),
        serial: digits(p && p.serial),
        conf: Math.max(0, Math.min(1, Number(p && p.confidence) || 0))
      }))
      .filter(p => p.serial.length >= 3)
      .slice(0, 5);
    return { plates: plates };
  } catch (e) {
    return { error: 'Gemini ka response samajh nahi aaya. Dobara scan karo.' };
  }
}


/* Photo -> Gemini -> sheet match -> rider data (client yahi call karta hai) */
function scanPlate(b64, pin, mime) {
  const bad = checkPin_(pin);
  if (bad) return { error: bad };
  if (!b64) return { error: 'Photo nahi mili.' };


  const g = askGemini_(b64, mime);
  if (g.error) return { error: g.error };
  if (!g.plates.length) return { error: 'Photo me plate nahi dikhi.', retry: true };


  let S = readSheet_(false);
  if (S.error) return { error: S.error };


  g.plates.sort((a, b) => b.conf - a.conf);


  function tryAll() {
    let lastErr = null;
    for (const p of g.plates) {
      const text = (p.prefix ? p.prefix + '/' : '') + p.serial;
      const r = findRider_(text, S);
      if (!r.error) return { ok: r };
      lastErr = r.error;
    }
    return { err: lastErr };
  }


  let res = tryAll();
  if (res.ok) return res.ok;


  // Cache purana ho sakta hai (naya rider add hua ho) -> taza data se ek baar aur
  if (S.fromCache) {
    const S2 = readSheet_(true);
    if (!S2.error) {
      S = S2;
      res = tryAll();
      if (res.ok) return res.ok;
    }
  }


  const seen = g.plates.map(p => (p.prefix ? p.prefix + '/' : '') + p.serial).join(', ');
  return { error: 'Gemini ne padha: ' + seen + ' - ' + res.err, retry: true };
}


/* Manual type karke search */
function findRider(ocrText, pin) {
  const bad = checkPin_(pin);
  if (bad) return { error: bad };
  let S = readSheet_(false);
  if (S.error) return { error: S.error };
  let r = findRider_(ocrText, S);
  if (r.error && S.fromCache) {
    const S2 = readSheet_(true);
    if (!S2.error) r = findRider_(ocrText, S2);
  }
  return r;
}


/* Plate text se rider ka poora data (photo alag se aati hai) */
function findRider_(ocrText, S) {
  const data = S.data, vCol = S.vCol;
  const text = String(ocrText || '').trim();
  const tokens = (text
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .match(/\d+/g)) || [];
  if (!tokens.length) return { error: 'Plate number nahi padha gaya. Dobara scan karo ya type karo.' };

  const rows = [];
  for (let r = 1; r < data.length; r++) {
    const raw = String(data[r][vCol] || '').trim();
    if (!raw) continue;
    const parts = raw.split('/');
    const plateTokens = raw
      .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
      .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
      .match(/\d+/g) || [];
    rows.push({
      row: r,
      raw: raw,
      parts: parts,
      toks: plateTokens,
      joined: digits(raw)
    });
  }

  // Prefer full prefix + serial. Never silently pick the first duplicate plate.
  let matches = [];
  if (tokens.length >= 2) {
    const pre = tokens[0], ser = tokens[tokens.length - 1];
    matches = rows.filter(x => x.parts.length === 2 &&
      digits(x.parts[0]) === pre && digits(x.parts[1]) === ser);
  }
  if (!matches.length) {
    const joined = tokens.join('');
    if (joined.length >= 5) matches = rows.filter(x => x.joined === joined);
  }
  if (!matches.length) {
    const serial = tokens[tokens.length - 1];
    if (serial.length >= 5) {
      matches = rows.filter(x => {
        const p = x.parts;
        return digits(p[p.length - 1]) === serial;
      });
    }
  }

  if (matches.length > 1) {
    return { error: 'Is plate/serial ke multiple riders mile. Accuracy ke liye poora plate prefix/number type karo.' };
  }
  if (!matches.length) return { error: 'Is plate ka rider nahi mila: ' + tokens.join(' ') };

  const hit = matches[0].row;
  const info = {};
  S.head.forEach((h, c) => {
    if (h && c !== S.pCol) info[h] = data[hit][c];
  });
  info['Vehicle no'] = data[hit][vCol];
  return {
    info: info,
    photoRow: S.pCol >= 0 ? hit + 1 : 0,
    photoCol: S.pCol >= 0 ? S.pCol + 1 : 0
  };
}


/* Page khulte hi call hota hai: server + sheet cache pehle se garam ho jate hain, pehla scan tez hota hai */
function warmup() {
  try { readSheet_(false); } catch (e) {}
  return true;
}


/* Rider ki photo alag call me (card pehle dikh jata hai, photo baad me aati hai) */
function fetchPhoto(row, col, pin) {
  const bad = checkPin_(pin);
  if (bad) return '';
  const S = readSheet_(false);
  if (S.error) return '';
  return getPhoto(S.sh, Number(row), Number(col));
}


/* Photo: chhoti ho to original, badi ho to Drive thumbnail */
function getPhoto(sh, row, col) {
  try {
    if (col < 1 || row < 1) return '';
    const cell = sh.getRange(row, col);
    let url = null;
    const rt = cell.getRichTextValue();
    if (rt) {
      url = rt.getLinkUrl();
      if (!url) rt.getRuns().forEach(r => { if (r.getLinkUrl()) url = r.getLinkUrl(); });
    }
    if (!url) url = String(cell.getValue() || '');
    let file = null;
    const m = url.match(/[-\w]{25,}/);
    if (m) { try { file = DriveApp.getFileById(m[0]); } catch (e) {} }
    if (!file) {
      const name = String(cell.getDisplayValue() || '').trim();
      if (name) { const it = DriveApp.getFilesByName(name); if (it.hasNext()) file = it.next(); }
    }
    if (!file) return '';


    let b = file.getBlob();
    let bytes = b.getBytes();
    if (bytes.length > 150 * 1024) { // card me photo chhoti dikhti hai, thumbnail kaafi hai
      try {
        const t = file.getThumbnail();
        if (t) { b = t; bytes = b.getBytes(); }
      } catch (e) {}
    }
    if (bytes.length > 1.5 * 1024 * 1024) return '';
    return 'data:' + b.getContentType() + ';base64,' + Utilities.base64Encode(bytes);
  } catch (e) { return ''; }
}

