RIDER SCANNER - LIVE CAMERA FIX (Android Chrome)

IMPORTANT:
Google Apps Script HTML Service restricts getUserMedia() inside its sandbox. Therefore, for true live camera scanning, the included Camera.html must be hosted on a separate HTTPS website. Code.gs and Index.html remain in Apps Script. Camera.html opens in a separate browser tab, captures live frames, and sends them back to the Apps Script page for Gemini matching.

FILES:
1. Code.gs       -> Google Apps Script backend
2. Index.html    -> Google Apps Script main UI
3. Camera.html   -> Separate live-camera page (host outside Apps Script)

SETUP A - HOST Camera.html ON GITHUB PAGES (free)
1. Sign in to GitHub.
2. Create a new public repository named: rider-camera
3. Upload Camera.html into the repository root. Keep the filename exactly Camera.html.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait until GitHub Pages shows the published HTTPS URL. It should look like:
   https://YOUR-USERNAME.github.io/rider-camera/Camera.html
7. Open that URL directly once to confirm the page loads. Camera permission should be requested only when Start Live Camera is tapped from the scanner popup.

SETUP B - CONNECT THE CAMERA PAGE
1. Open Index.html in a text editor.
2. Find these two constants near the start of the script:
   const CAMERA_PAGE_URL = 'https://YOUR-USERNAME.github.io/rider-camera/Camera.html';
   const CAMERA_ORIGIN = 'https://YOUR-USERNAME.github.io';
3. Replace YOUR-USERNAME in both lines with your actual GitHub username. Do not add a slash to CAMERA_ORIGIN.
   Example if username is batlaexample:
   CAMERA_PAGE_URL = 'https://batlaexample.github.io/rider-camera/Camera.html'
   CAMERA_ORIGIN = 'https://batlaexample.github.io'
4. Save and paste the full Index.html into Apps Script HTML file named Index.

SETUP C - APPS SCRIPT
1. Open the Google Sheet -> Extensions -> Apps Script.
2. Replace Code.gs with the supplied Code.gs.
3. Replace the existing Index HTML file with supplied Index.html. The HTML file name must be Index.
4. In Project Settings -> Script Properties, set:
   GEMINI_KEY = your Gemini API key
   PIN = your private scanner PIN
5. Save. Deploy -> Manage deployments -> Edit -> New version -> Deploy.
6. Open the deployed /exec web-app link directly in Chrome on Android (not inside WhatsApp/Google Sites).
7. Enter PIN, tap PLATE SCAN KARO, then on the new camera tab tap START LIVE CAMERA and allow camera access.

TEST / TROUBLESHOOTING
- If Chrome blocks the new tab, allow pop-ups for the Apps Script web-app site and retry.
- If camera permission is denied, Android Settings -> Apps -> Chrome -> Permissions -> Camera -> Allow while using app; also check Chrome site settings.
- The Camera.html URL must use HTTPS and must match CAMERA_PAGE_URL / CAMERA_ORIGIN exactly.
- The spreadsheet must contain a tab named Info with headers including Vehicle No and the rider details expected by your existing sheet.
- This code has had local JavaScript syntax checks only. The GitHub Pages URL, Apps Script deployment, Gemini API key, camera hardware and real vehicle plates must be tested in your account/device.
